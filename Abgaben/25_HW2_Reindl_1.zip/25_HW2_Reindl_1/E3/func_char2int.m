function i = func_char2int(s)
% 
%
%
%
% Neumayer 2017

i = 0;
if strcmp(s,'a')   i =  1; end
if strcmp(s,'b')   i =  2; end
if strcmp(s,'c')   i =  3; end
if strcmp(s,'d')   i =  4; end
if strcmp(s,'e')   i =  5; end
if strcmp(s,'f')   i =  6; end
if strcmp(s,'g')   i =  7; end
if strcmp(s,'h')   i =  8; end
if strcmp(s,'i')   i =  9; end
if strcmp(s,'j')   i = 10; end
if strcmp(s,'k')   i = 11; end
if strcmp(s,'l')   i = 12; end
if strcmp(s,'m')   i = 13; end
if strcmp(s,'n')   i = 14; end
if strcmp(s,'o')   i = 15; end
if strcmp(s,'p')   i = 16; end
if strcmp(s,'q')   i = 17; end
if strcmp(s,'r')   i = 18; end
if strcmp(s,'s')   i = 19; end
if strcmp(s,'t')   i = 20; end
if strcmp(s,'u')   i = 21; end
if strcmp(s,'v')   i = 22; end
if strcmp(s,'w')   i = 23; end
if strcmp(s,'x')   i = 24; end
if strcmp(s,'y')   i = 25; end
if strcmp(s,'z')   i = 26; end

if strcmp(s,' ')   i = 27; end


if strcmp(s,'0')   i = 28; end
if strcmp(s,'1')   i = 29; end
if strcmp(s,'2')   i = 30; end
if strcmp(s,'3')   i = 31; end
if strcmp(s,'4')   i = 32; end
if strcmp(s,'5')   i = 33; end
if strcmp(s,'6')   i = 34; end
if strcmp(s,'7')   i = 35; end
if strcmp(s,'8')   i = 36; end
if strcmp(s,'9')   i = 37; end

if strcmp(s,'.')   i = 38; end
%i = i+1;